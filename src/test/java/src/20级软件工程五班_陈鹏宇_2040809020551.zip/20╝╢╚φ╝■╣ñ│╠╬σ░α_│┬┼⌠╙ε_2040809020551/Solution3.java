package src;

import java.util.HashSet;
import java.util.Set;

public class Solution3 {
    /**
     * 快乐数
     * @param n
     * @return
     */
    public boolean isHappy(int n) {
        Set<Integer> record = new HashSet<>();
        while (n != 1 && !record.contains(n)) {
            record.add(n);
            n = getNextNumber(n);
        }
        return n == 1;
    }

    private int getNextNumber(int n) {
        int res = 0;
        while (n > 0) {
            // 对各位上面的数取出求值
            int temp = n % 10;
            res += temp * temp;
            n = n / 10;
        }
        return res;
    }
}

